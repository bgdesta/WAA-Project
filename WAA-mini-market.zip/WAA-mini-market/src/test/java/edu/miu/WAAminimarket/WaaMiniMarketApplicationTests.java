package edu.miu.WAAminimarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaaMiniMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
